# 3D X-Ray Shader : Plane Clipping + Fresnel + CrossSection Highlight

https://polyandcode.com<br />
https://twitter.com/polyandcode || https://www.facebook.com/Polyandcode || https://www.instagram.com/polyandcode/

![Imgur Image](https://i.imgur.com/cQWCtgZ.gif)

![Imgur Image](https://i.imgur.com/M3Y2CZb.gif)

![Imgur Image](https://i.imgur.com/6wbZxZ0.gif)
